
export class Store {
  constructor(
    public id?: number, //same
    public itemName?: string,
    public category?: string,
    public description?: string,
    public src?: string,
    public price?: number
  ) {}
}
