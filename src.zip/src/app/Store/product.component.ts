import { Component, Input } from '@angular/core';
import { Store } from '../model/store.model';
import { Repository } from '../model/repository';
import { User } from '../model/user.model';

@Component({
  selector: 'app-product-card',
  templateUrl: 'product.component.html',
  styleUrls: ['product.component.css'],
})

export class ProductCardComponent {
  @Input() product!: Store;
  @Input() userId!: string;  // ✅ Take userId from parent component
  public seeMore = false;

  constructor(private repo: Repository) {}

  update() {
    this.seeMore = !this.seeMore;
  }

addToCart(productId?: number) {
  if (productId !== undefined) {
    this.repo.addToCart(this.userId, productId, 1).subscribe(() => {
      alert("Item added to cart!");
    });
  } else {
    console.error("Product ID is missing!");
  }
}





}


