import { Component, OnInit } from '@angular/core';
import { Repository } from '../model/repository';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  userId: string = "user123"; // 🚨 same userId

  constructor(private repo: Repository) {}

  ngOnInit() {
    this.loadCart();
  }

  loadCart() {
    this.repo.getCart(this.userId).subscribe(data => {
      this.cart = data;
    });
  }
}
