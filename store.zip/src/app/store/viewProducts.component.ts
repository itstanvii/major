import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductRepository } from '../model/product_repository';
import { Store } from '../model/store.model';

@Component({
  selector: 'view-products',
  templateUrl: 'viewProducts.component.html',
})
export class ViewProductsComponent implements OnInit {
  store: Store[] = [];
  category: string = '';

  constructor(private repo: ProductRepository, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.category = params['category'];

      this.repo.getAllProducts().subscribe((data) => {
        console.log('Fetched products:', data);
        console.log('Selected category:', this.category);

        this.store = this.category
          ? data.filter((product) => product.category === this.category)
          : data;

        console.log('Filtered products:', this.store);
      });
    });
  }
}
