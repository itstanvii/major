import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'thank',
  templateUrl: 'thank.component.html',
  styleUrls: ['thank.component.css'],
})
export class ThankComponent {
  constructor() {}
}
