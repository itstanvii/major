import { RestDataSource } from './restDataSource';
import { Observable, shareReplay } from 'rxjs';
import { Injectable } from '@angular/core';
import { Store } from './store.model';

@Injectable({
  providedIn: 'root',
})
export class ProductRepository {
  // SRP - CRUD methods

  private products: Store[] = []; // 15 object --- data aware states !
  private loaded = false;

  constructor(private dataSource: RestDataSource) {}
  // private products$ = this.dataSource.getProducts().pipe(shareReplay(1));

  getAllProducts(): Observable<Store[]> {
    // console.log(this.dataSource.getProducts());
    return this.dataSource.getProducts();
  }
  saveProduct(product: Store) {
    this.dataSource
      .saveProduct(product)
      .subscribe((p) => this.products.push(p));
  }
  deleteProduct(id?: number) {
    this.dataSource.deleteProduct(id).subscribe((p) => {
      this.products.splice(
        this.products.findIndex((p) => p.id == id),
        1
      );
    });
  }
}
