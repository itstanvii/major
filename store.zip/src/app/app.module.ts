import { ViewProductsComponent } from './store/viewProducts.component';
import { homeComponent } from './store/home.component';
import { StoreComponent } from './store/form.component';
import { StoreModule } from './store/store.module';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { RestDataSource } from './model/restDataSource';
import { ProductRepository } from './model/product_repository';
import { ThankComponent } from './store/thank.component';

@NgModule({
  declarations: [
    // register component,directives & pipes (non-services)
    AppComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path: 'store',
        component: StoreComponent,
      },
      {
        path: 'home',
        component: homeComponent,
      },
      {
        path: 'view-plans',
        component: ViewProductsComponent,
      },
      {
        path: 'thank',
        component: ThankComponent,
      },

      {
        path: 'admin',
        loadChildren: () =>
          import('./admin/admin.module').then((m) => m.AdminModule),
      },
      {
        path: '**',
        redirectTo: '/home',
      },
      // RouterTree
    ]),
    StoreModule,
  ], // Blocking script| Preloading modules| Dependency modules| Wider modules
  providers: [RestDataSource, ProductRepository], // register & launch services (Injectables)
  bootstrap: [AppComponent], // launch a root component
})
export class AppModule {} // SRP -> register & launch a root component

// Root level entities should not directly try to interact with Model level entity
