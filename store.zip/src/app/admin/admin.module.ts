import { ViewProductsComponent } from '../store/viewProducts.component';
import { AuthComponent } from './authComponent';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { StoreModule } from '../store/store.module';

let routing = RouterModule.forChild([
  {
    path: 'auth',
    component: AuthComponent,
  },

  {
    path: 'main',
    component: AdminComponent,
    children: [
      { path: 'recipes', component: ViewProductsComponent }, //edit 1 product & path property is a subscriber. The info of mode & id is store in route comp
      // { path: '**', redirectTo: 'products' },
    ],
  },
  { path: '**', redirectTo: '/auth' },
]);

@NgModule({
  imports: [CommonModule, FormsModule, routing, StoreModule], // Dependency Modules
  providers: [],
  declarations: [AuthComponent, AdminComponent],
})
export class AdminModule {} // lazy loaded.
