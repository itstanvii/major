import { Component } from '@angular/core';

@Component({
  selector: 'app',
  template: '<router-outlet/>', // <store/>
})
export class AppComponent {
  constructor() {}
} // SRP - launch feature component
