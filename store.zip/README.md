<<<<<<< HEAD
# RecipeNest
=======
Project Overview -
RecipeNest - Recipe App

This Recipe App is a dynamic web application that allows users to explore a variety of recipes, upload their own creations, and view detailed recipe information with a "See More" feature. It supports both GET and POST requests for seamless data interaction. The app includes an admin panel secured with authentication, where only authorized admins can delete recipes, ensuring content moderation.

Team Members -
Yash Kawtikwar
Tanvi Jain
>>>>>>> c4d0077 (Initial commit)
