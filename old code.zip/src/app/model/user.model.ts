export class User {
  constructor(
    public id?: string,
    public name?: string,
    public email?: string,
    public password?: string,
    public category?: string,
    public height?: string,
    public weight?: string
  ) {}
}
