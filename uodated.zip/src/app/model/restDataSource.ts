import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Store } from './store.model';

const PROTOCOL = 'http';
const PORT = 3500;

@Injectable({
  providedIn: 'root',
})
export class RestDataSource {
  baseUrl: string;
  auth_token?: string;

  constructor(private http: HttpClient) {
    this.baseUrl = `${PROTOCOL}://${location.hostname}:${PORT}`;
  }

  saveProduct(product: Store): Observable<Store> {
    return this.http.post<Store>(this.baseUrl + '/items', product);
  }

  getProducts(): Observable<Store[]> {
    return this.http.get<Store[]>(this.baseUrl + '/items');
  }

  deleteProduct(id?: number): Observable<any> {
    if (!id) throw new Error('Product ID is required for deletion');
    return this.http.delete(`${this.baseUrl}/items/${id}`);
  }
}
