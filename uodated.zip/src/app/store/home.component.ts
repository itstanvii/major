import { ProductRepository } from './../model/product_repository';
import { NgForm } from '@angular/forms';
import { Store } from '../model/store.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'home',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],
})
export class homeComponent {
  //   filteredRecipes: any[] = [];
  //   recipes: Recipe[] = [];
  //   visible = false;
  //   categories: string[] = [
  //     'NorthIndia',
  //     'SouthIndia',
  //     'Chinese',
  //     'Maharashtrian',
  //   ];
  //   constructor(private repo: ProductRepository) {}
  //   ngOnInit() {
  //     // console.log(this.repo.getAllProducts());
  //     this.repo.getAllProducts().subscribe((data) => {
  //       this.recipes = data;
  //     });
  //   }

  //   filterByCategory(category: string) {
  //     this.filteredRecipes = this.recipes.filter(
  //       (recipe) => recipe.cuisine === category
  //     );
  //   }

  //   // save(form: NgForm) {}
  // }

  store: Store[] = [];
  filteredstore: Store[] = [];
  visible = false;

  category = [
    { name: 'Clothes', image: 'assets/images/c1.jpeg' },
    { name: 'Power Intake', image: 'assets/images/f1.jpeg' },
    { name: 'Weights', image: 'assets/images/w1.jpeg' },
    { name: 'Accessories', image: 'assets/images/a1.webp' },
  ];

  constructor(private repo: ProductRepository, private router: Router) {}

  goToCategory(category: string) {
    this.router.navigate(['/view-plans'], { queryParams: { category } });
  }

  ngOnInit(): void {
    this.repo.getAllProducts().subscribe((data) => {
      this.store = data;
    });
  }

  filterByCategory(category: string): void {
    this.filteredstore = this.store.filter(
      (store) => store.itemName === category
    );
  }
}
