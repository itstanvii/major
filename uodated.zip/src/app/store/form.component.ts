import { Store } from '../model/store.model';
import { NgForm } from '@angular/forms';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProductRepository } from '../model/product_repository';

@Component({
  selector: 'store',
  templateUrl: 'form.component.html',
  styleUrls: ['form.component.css'],
})
export class StoreComponent {
  product: Store = new Store();
  constructor(private repository: ProductRepository, private router: Router) {}
  save(form: NgForm) {
    this.repository.saveProduct(this.product);
    this.router.navigate(['/thank']);
  }
}
