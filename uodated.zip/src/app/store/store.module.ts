import { ViewProductsComponent } from './viewProducts.component';
import { homeComponent } from './home.component';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { StoreComponent } from './form.component';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ProductCardComponent } from './product.component';
import { NavbarComponent } from './nav.component';
import { ThankComponent } from './thank.component';

@NgModule({
  imports: [RouterModule, FormsModule, CommonModule],
  declarations: [
    StoreComponent,
    homeComponent,
    ViewProductsComponent,
    ProductCardComponent,
    NavbarComponent,
    ThankComponent,
  ], // Registeration & Launch
  exports: [StoreComponent, NavbarComponent, ProductCardComponent], // sharing/exposing components across modules/injector
})
export class StoreModule {} // register & launch feature components or non-services
