import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProductRepository } from '../model/product_repository';
import { Store } from '../model/store.model';

@Component({
  selector: 'adminComponent',
  templateUrl: 'admin.component.html',
  styleUrls: ['admin.component.css'],
})
export class AdminComponent {
  recipes: Store[] = [];

  constructor(private repo: ProductRepository, private route: Router) {
    this.repo.getAllProducts().subscribe((data: Store[]) => {
      this.recipes = data;
    });
  }

  deleteProduct(id?: number) {
    if (confirm('Are you sure you want to delete this recipe?')) {
      this.repo.deleteProduct(id);
      this.recipes = this.recipes.filter((recipe) => recipe.id !== id);
    }
  }

  logout() {
    this.route.navigateByUrl('/');
  }
}
