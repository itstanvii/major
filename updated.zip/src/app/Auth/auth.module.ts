import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AuthComponent } from './auth.component';
import { AdminComponent } from './admin.component';
import { AdminDeleteComponent } from './adminDelete.component';
import { AdminAddComponent } from './adminAdd.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,

    RouterModule.forChild([
      {
        path: 'adminLogin',
        component: AuthComponent,
      },
      {
        path: 'admin',
        component: AdminComponent,
      },
      {
        path: 'Remove',
        component: AdminDeleteComponent,
      },
      {
        path: 'edit',
        component: AdminAddComponent,
      },
    ]),
  ],
  declarations: [
    AuthComponent,
    AdminComponent,
    AdminDeleteComponent,
    AdminAddComponent,
  ],
  providers: [],
})
export class AuthModule {}
