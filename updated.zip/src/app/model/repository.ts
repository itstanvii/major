import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RestDataSource } from './restDataSource';
import { User } from './user.model';
import { Trainer } from './trainer.model';
import { Store } from './store.model';

@Injectable({
  providedIn: 'root',
})
export class Repository {
  private products: Store[] = [];
  private user: User[] = [];
  private trainer: Trainer[] = [];

  constructor(private dataSource: RestDataSource) {}

  getAllUsers(): Observable<User[]> {
    return this.dataSource.getAllUsers();
  }

  saveUser(user: User): Observable<User> {
    return this.dataSource.saveUser(user);
  }

  updateUser(id: number, user: User): Observable<User> {
    return this.dataSource.updateUser(id, user);
  }

  saveTrainers(trainer: Trainer): Observable<Trainer> {
    return this.dataSource.saveTrainer(trainer);
  }

  getAllTrainers(): Observable<Trainer[]> {
    return this.dataSource.getAllTrainers();
  }

  getAllProducts(): Observable<Store[]> {
    return this.dataSource.getProducts();
  }

  saveProduct(product: Store): Observable<Store> {
    return this.dataSource.saveProduct(product);
  }

  deleteProduct(id: number): Observable<any> {
    return this.dataSource.deleteProduct(id);
  }

  updateProduct(product: Store): Observable<Store> {
    return this.dataSource.updateProduct(product);
  }
}
