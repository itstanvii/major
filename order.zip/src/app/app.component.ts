import { Component } from '@angular/core';

@Component({
  selector: 'app',
  template: `
    <div class="dark-theme">
      <router-outlet></router-outlet>
    </div>
  `,
})
export class AppComponent {
  title = 'GMS';
}
