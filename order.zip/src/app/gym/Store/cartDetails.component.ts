import { Component, OnInit } from '@angular/core';
import { Store } from '../../model/store.model';
import { Repository } from '../../model/repository';
import { User } from '../../model/user.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Orders } from '../../model/orders.model';

@Component({
  selector: 'cart-details',
  templateUrl: 'cartDetails.component.html'
})

export class CartDetails implements OnInit {
    items: { product: Store; quantity: number }[] = [];
    total = 0;
    userId!: string;
    userData: any;
      address: string = "";
  constructor(private repo: Repository , private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
    this.loadCart();
    this.userId = this.route.snapshot.paramMap.get('id')!;
        this.repo.getAllUsers().subscribe((data) => {
      this.userData = data.find((u) => u && u.id === this.userId);
    });
    console.log(this.userData)
    console.log(this.userData.id)
  }

  private loadCart() {
      const logged = localStorage.getItem('logged');
      if (!logged) return;
      const user: User = JSON.parse(logged);
      const cart = user.cart || [];
      this.repo.getAllProducts().subscribe((products) => {
        this.items = cart
          .map((c) => {
            const product = products.find((p) => String(p.id) === c.productId);
            if (!product) return undefined as any;
            return { product, quantity: c.quantity };

          })
          .filter(Boolean);
        this.calculateTotal();
      });
    }
    private calculateTotal() {
    this.total = this.items.reduce((sum, i) => sum + Number(i.product.price || 0) * i.quantity, 0);
  }

  saveOrder() {
  if (!this.userData) return;
  const orderId = Date.now().toString();
  const order = new Orders(
    orderId,
    this.userData.id,     // user id
    this.userData.name,   // name
    this.userData.email,  // email
    this.address,         // address from input
    this.userData.cart    // cart data
  );

  this.repo.saveOrders(order);

    const updatedUser = { ...this.userData, cart: [] };

  this.repo.updateUser(this.userData.id, updatedUser).subscribe(() => {
    // also update localStorage if you’re using it for logged in user
    localStorage.setItem("logged", JSON.stringify(updatedUser));

    alert("Order placed successfully!");
    this.router.navigate(['/store']);
  });
}



}
