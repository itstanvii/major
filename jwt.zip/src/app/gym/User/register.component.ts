import { Repository } from '../../model/repository';
import { Component } from '@angular/core';
import { User } from '../../model/user.model';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'register',
  templateUrl: 'register.component.html',
})
export class RegisterComponent {
  userForm!: FormGroup;

  user: User = new User();
  constructor(
    private router: Router,
    private repository: Repository,
    private fb: FormBuilder
  ) {}
  ngOnInit(): void {
    this.userForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      age: ['', [Validators.required, Validators.min(1), Validators.max(120)]],
      imageUrl: ['', Validators.required],
      height: [
        '',
        [Validators.required, Validators.min(0.5), Validators.max(2.5)],
      ],
      weight: [
        '',
        [Validators.required, Validators.min(20), Validators.max(200)],
      ],
      category: ['', Validators.required],
    });
  }

  save(): void {
    if (this.userForm.valid) {
      const formData = this.userForm.value;
      this.repository.saveUser(formData);
      this.router.navigate(['/home']);
      console.log('User saved:', this.user);
    } else {
      console.log('Form is invalid');
    }
  }
}
