import { Router } from '@angular/router';
import { Repository } from '../../model/repository';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'login',
  templateUrl: 'login.component.html',
})
export class LoginComponent {
  credientials = { email: '', password: '' };
  message = '';

  constructor(private repositoy: Repository, private router: Router) {}

  login() {
    this.repositoy
      .getUserByCredentials(this.credientials.email, this.credientials.password)
      .subscribe((users) => {
        const user = users && users.length ? users[0] : null;
        if (user) {
          localStorage.setItem('logged', JSON.stringify(user));
          this.message = 'login successfully';
          this.router.navigate(['/home']);
        } else {
          this.message = 'Invalid email or password';
        }
      });
  }
}
